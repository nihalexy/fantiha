import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

const characters = [
  { name: "Eira", trait: "Cool and mysterious" },
  { name: "Tillo", trait: "Clingy but sweet" },
  { name: "Seraphine", trait: "Elegant and noble" },
  { name: "Zan", trait: "Chaotic energy" },
];

const worlds = ["The Skylands", "Ecliptor Forest", "Aurelia", "Duskrealm"];

export default function Fantiha() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-green-900 to-white text-white p-6">
      <h1 className="text-4xl font-bold text-center mb-6 text-yellow-300">Fantiha</h1>
      <Tabs defaultValue="home" className="w-full max-w-4xl mx-auto">
        <TabsList className="grid grid-cols-4 bg-white text-black">
          <TabsTrigger value="home">Home</TabsTrigger>
          <TabsTrigger value="characters">Choose Character</TabsTrigger>
          <TabsTrigger value="world">Choose World</TabsTrigger>
          <TabsTrigger value="about">About Yourself</TabsTrigger>
        </TabsList>

        <TabsContent value="home">
          <Card>
            <CardContent className="p-6">
              <h2 className="text-2xl font-semibold mb-2">Welcome to Fantiha</h2>
              <p>
                Create your own fantasy universe. Meet unique characters and explore magical worlds. Who will you talk to today?
              </p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="characters">
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mt-4">
            {characters.map((char, index) => (
              <Card key={index} className="bg-purple-800 text-white hover:shadow-lg">
                <CardContent className="p-4">
                  <h3 className="text-xl font-bold">{char.name}</h3>
                  <p>{char.trait}</p>
                  <Button className="mt-2 bg-yellow-400 text-black hover:bg-yellow-500">
                    Talk to {char.name}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="world">
          <div className="grid grid-cols-2 gap-4 mt-4">
            {worlds.map((world, index) => (
              <Card key={index} className="bg-green-800 text-white hover:shadow-lg">
                <CardContent className="p-4">
                  <h3 className="text-xl font-bold">{world}</h3>
                  <Button className="mt-2 bg-white text-black hover:bg-gray-200">
                    Enter {world}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="about">
          <Card>
            <CardContent className="p-6 space-y-4">
              <h2 className="text-xl font-semibold">Tell us about yourself</h2>
              <Input placeholder="Your name" />
              <Textarea placeholder="Describe your fantasy self..." />
              <Button className="bg-purple-500 hover:bg-purple-700 text-white">
                Save
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}